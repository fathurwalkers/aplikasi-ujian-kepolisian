<?php $__env->startSection('title', 'Ujian Kepolisian'); ?>
<?php $__env->startSection('content-prefix', 'Daftar UKOM'); ?>
<?php $__env->startSection('content-header', 'Dashboard - Daftar UKOM'); ?>

<?php $__env->startPush('css'); ?>
    
    <link href="<?php echo e(asset('datatables')); ?>/datatables.min.css" rel="stylesheet">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('main-content'); ?>

    <div class="card mb-3">
        <div class="card-body">
            <div class="container">
                <div class="row">
                    <div class="col-sm-6 col-md-6 col-lg-6">
                        <h4>
                            <b>
                                Daftar UKOM
                            </b>
                        </h4>
                    </div>
                    <div class="col-sm-6 col-md-6 col-lg-6 d-flex justify-content-end">
                        <button class="btn btn-md btn-info" data-toggle="modal" data-target="#tambahdatamodal">TAMBAH
                            DATA</button>
                    </div>

                    
                    <div class="modal fade" id="tambahdatamodal" tabindex="-1" role="dialog"
                        aria-labelledby="exampleModalLabelLogout" aria-hidden="true">
                        <div class="modal-dialog" role="document">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="exampleModalLabelLogout">Form Tambah Data UKOM</h5>
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                                <form action="<?php echo e(route('post-tambah-ukom')); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <div class="modal-body">

                                        <div class="row">
                                            <div class="col-sm-12 col-md-12 col-lg-12">
                                                <div class="form-group">
                                                    <label for="ukom_nama">Uji Kompetensi</label>
                                                    <input type="text" class="form-control" id="ukom_nama"
                                                        placeholder="Contoh : Bahasa Indonesia" name="ukom_nama">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-sm-12 col-md-12 col-lg-12">
                                                <div class="form-group">
                                                    <label for="ukom_kategori">Kategori</label>
                                                    <select class="custom-select" id="inputGroupSelect01"
                                                        name="ukom_kategori">
                                                        <option default value="reguler">REGULER</option>
                                                        <option value="kecermatan">KECERMATAN</option>
                                                        <option value="kepribadian">KEPRIBADIAN</option>
                                                        <option value="kecerdasan">KECERDASAN</option>
                                                        <option value="campur">CAMPUR</option>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>

                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-outline-primary"
                                            data-dismiss="modal">Batalkan</button>
                                        <button type="submit" class="btn btn-primary">Simpan</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>

                </div>
                <hr />
                <div class="row">
                    <div class="table-responsive">
                        <table id="example" class="display table-bordered" style="width:100%">
                            <thead class="thead-dark">
                                <tr>
                                    <th>No.</th>
                                    <th>UKOM</th>
                                    <th>Kategori UKOM</th>
                                    <th>Kode UKOM</th>
                                    <th>Opsi</th>
                                </tr>
                            </thead>
                            <tbody>

                                <?php $__currentLoopData = $ukom; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($loop->iteration); ?></td>
                                        <td><?php echo e($item->ukom_nama); ?></td>
                                        <td><?php echo e(strtoupper($item->ukom_kategori)); ?></td>
                                        <td><?php echo e($item->ukom_kode); ?></td>
                                        <td class="d-flex justify-content-center mx-auto">

                                            <div class="row btn-group">
                                                <div class="col-sm-12 col-md-12 col-lg-12 btn-group">
                                                    
                                                    <button type="button" class="btn btn-sm btn-info mr-1"
                                                        data-toggle="modal" data-target="#modalupdate<?php echo e($item->id); ?>">
                                                        Ubah
                                                    </button>
                                                    <button type="button" class="btn btn-sm btn-danger" data-toggle="modal"
                                                        data-target="#modalhapus<?php echo e($item->id); ?>">
                                                        Hapus
                                                    </button>
                                                </div>
                                            </div>

                                            
                                            <div class="modal fade" id="modalupdate<?php echo e($item->id); ?>" tabindex="-1"
                                                role="dialog" aria-labelledby="exampleModalLabelLogout" aria-hidden="true">
                                                <div class="modal-dialog" role="document">
                                                    <div class="modal-content">
                                                        <div class="modal-header">
                                                            <h5 class="modal-title" id="exampleModalLabelLogout">Form Ubah
                                                                Data UKOM</h5>
                                                            <button type="button" class="close" data-dismiss="modal"
                                                                aria-label="Close">
                                                                <span aria-hidden="true">&times;</span>
                                                            </button>
                                                        </div>
                                                        <form action="<?php echo e(route('update-ukom', $item->id)); ?>" method="POST">
                                                            <?php echo csrf_field(); ?>
                                                            <div class="modal-body">

                                                                <div class="row">
                                                                    <div class="col-sm-12 col-md-12 col-lg-12">
                                                                        <div class="form-group">
                                                                            <label for="ukom_nama">Uji Kompetensi</label>
                                                                            <input type="text" class="form-control"
                                                                                id="ukom_nama"
                                                                                value="<?php echo e($item->ukom_nama); ?>"
                                                                                name="ukom_nama">
                                                                        </div>
                                                                    </div>
                                                                </div>

                                                            </div>
                                                            <div class="modal-footer">
                                                                <button type="button" class="btn btn-outline-primary"
                                                                    data-dismiss="modal">Batalkan</button>
                                                                <button type="submit"
                                                                    class="btn btn-primary">Simpan</button>
                                                            </div>
                                                        </form>
                                                    </div>
                                                </div>
                                            </div>

                                            
                                            <div class="modal fade" id="modalhapus<?php echo e($item->id); ?>" tabindex="-1"
                                                role="dialog" aria-labelledby="exampleModalLabelLogout"
                                                aria-hidden="true">
                                                <div class="modal-dialog" role="document">
                                                    <div class="modal-content">
                                                        <div class="modal-header">
                                                            <h5 class="modal-title" id="exampleModalLabelLogout">Ohh No!
                                                            </h5>
                                                            <button type="button" class="close" data-dismiss="modal"
                                                                aria-label="Close">
                                                                <span aria-hidden="true">&times;</span>
                                                            </button>
                                                        </div>

                                                        <form action="<?php echo e(route('hapus-ukom', $item->id)); ?>"
                                                            method="POST">
                                                            <?php echo csrf_field(); ?>
                                                            <input type="hidden" name="id_ukom"
                                                                value="<?php echo e($item->id); ?>">
                                                            <div class="modal-body">
                                                                <div class="row">
                                                                    <div class="col-sm-12 col-md-12 col-lg-12">
                                                                        Apakah anda Yakin ingin menghapus data ini?
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="modal-footer">
                                                                <button type="button" class="btn btn-outline-primary"
                                                                    data-dismiss="modal">Batalkan</button>
                                                                <button type="submit"
                                                                    class="btn btn-primary">Simpan</button>
                                                            </div>
                                                        </form>

                                                    </div>
                                                </div>
                                            </div>

                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
    <script src="<?php echo e(asset('datatables')); ?>/datatables.min.js"></script>
    <script>
        $(document).ready(function() {
            $('#example').DataTable();
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.dashboard-layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\IT Ecoasphalt\Desktop\htdocs\ujikom\resources\views/ukom/data-ukom.blade.php ENDPATH**/ ?>
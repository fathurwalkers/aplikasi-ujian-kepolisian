<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <!-- plugins:css -->
    <?php echo $__env->yieldPushContent('css'); ?>

</head>

<body>
    <!-- navbar -->
    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.client-dashboard-navbar','data' => []]); ?>
<?php $component->withName('client-dashboard-navbar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
    <!-- akhir navbar -->

    <!-- konten -->
    
    <div class="container" style="margin-top: 100px; margin-bottom: 100px;">

        <div class="row row-cols-1 justify-content-center mx-auto">
            <div class="col-sm-12 col-md-12 col-lg-12 justify-content-center mx-auto">
                <?php echo $__env->yieldContent('header-content'); ?>
            </div>
        </div>

        <?php echo $__env->yieldContent('main-content'); ?>
    </div>
    <!-- akhir konten -->

    <!-- footer -->
    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.client-dashboard-footer','data' => []]); ?>
<?php $component->withName('client-dashboard-footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
    <!-- akhir footer -->

    <!-- akhir footer -->

    <?php echo $__env->yieldPushContent('js'); ?>
</body>

</html>
<?php /**PATH C:\Users\IT Ecoasphalt\Desktop\htdocs\ujikom\resources\views/layouts/client-layouts.blade.php ENDPATH**/ ?>
<div>
    <footer>
        <div class="container-fluid bg-primary fixed-bottom">
            <ul>
                <li><a href="<?php echo e(route('client-index')); ?>"><i class="bi bi-house-fill text-light "></i></a>Home</li>
                
                <li><a href="<?php echo e(route('client-profile')); ?>"><i class="bi bi-person-circle text-light"></i></a>profil</li>
                
            </ul>
        </div>
    </footer>
</div>
<?php /**PATH C:\Users\IT Ecoasphalt\Desktop\htdocs\ujikom\resources\views/components/client-dashboard-footer.blade.php ENDPATH**/ ?>
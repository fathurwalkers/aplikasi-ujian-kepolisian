<?php $__env->startSection('title', 'Ujian Kepolisian'); ?>
<?php $__env->startSection('content-prefix', 'Bank Soal'); ?>
<?php $__env->startSection('content-header', 'Dashboard - Bank Soal'); ?>

<?php $__env->startPush('css'); ?>
    
    <link href="<?php echo e(asset('datatables')); ?>/datatables.min.css" rel="stylesheet">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('main-content'); ?>

    <div class="card mb-3">
        <div class="card-body">
            <div class="container">
                <div class="row">
                    <div class="col-sm-6 col-md-6 col-lg-6">
                        <h4>
                            <b>
                                Daftar Uji Kompetensi
                            </b>
                        </h4>
                    </div>
                    <div class="col-sm-6 col-md-6 col-lg-6 d-flex justify-content-end">
                        <button class="btn btn-sm btn-info" data-toggle="modal" data-target="#tambahdatamodal">
                            <b>
                                TAMBAH DATA
                            </b>
                        </button>
                    </div>

                    
                    <div class="modal fade" id="tambahdatamodal" tabindex="-1" role="dialog"
                        aria-labelledby="exampleModalLabelLogout" aria-hidden="true">
                        <div class="modal-dialog" role="document">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="exampleModalLabelLogout">Form Tambah Data UKOM</h5>
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                                <form action="<?php echo e(route('post-tambah-ujian')); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <div class="modal-body">

                                        <div class="row">
                                            <div class="col-sm-6 col-md-6 col-lg-6">
                                                <div class="form-group">
                                                    <label for="ujian_nama">Nama Ujian</label>
                                                    <input type="text" class="form-control" id="ujian_nama"
                                                        placeholder="Contoh : Bahasa Indonesia" name="ujian_nama">
                                                </div>
                                            </div>
                                            <div class="col-sm-6 col-md-6 col-lg-6">
                                                <div class="form-group">
                                                    <label for="ujian_menit">Waktu (Menit)</label>
                                                    <input type="number" class="form-control" id="ujian_menit"
                                                        placeholder="Contoh : Bahasa Indonesia" name="ujian_menit"
                                                        maxlength="3">
                                                </div>
                                            </div>
                                        </div>

                                        <div class="row">
                                            <div class="col-sm-12 col-md-12 col-lg-12">
                                                <div class="form-group">
                                                    <label for="ukom_id">Pilih UKOM</label>
                                                    <select class="custom-select" id="inputGroupSelect01" name="ukom_id"
                                                        aria-placeholder="...">
                                                        <?php $__currentLoopData = $ukom; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($item->id); ?>">
                                                                <?php echo e($item->ukom_nama); ?>

                                                            </option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>

                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-outline-warning"
                                            data-dismiss="modal">Batalkan</button>
                                        <button type="submit" class="btn btn-info">Tambah Data</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>

                </div>
                <hr />
                <div class="row">
                    <div class="table-responsive">
                        <table id="example" class="display table-bordered" style="width:100%">
                            <thead class="thead-dark">
                                <tr>
                                    <th>No.</th>
                                    <th>Ujian</th>
                                    <th>Waktu</th>
                                    <th>Jumlah Soal</th>
                                    <th>Token</th>
                                    <th>Status</th>
                                    <th>Tanggal dibuat</th>
                                    <th>UKOM</th>
                                    <th>Opsi</th>
                                </tr>
                            </thead>

                            <tbody>

                                <?php $__currentLoopData = $ujian; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($loop->iteration); ?></td>
                                        <td><?php echo e($item->ujian_nama); ?></td>
                                        <td><?php echo e($item->ujian_menit); ?> Menit</td>
                                        <td><?php echo e($item->ujian_jumlah_soal); ?></td>
                                        <td><?php echo e($item->ujian_token); ?></td>
                                        <td><?php echo e($item->ujian_status); ?></td>
                                        <td><?php echo e(date('d-m-Y / H:i', strtotime($item->ujian_tanggal_dibuat))); ?></td>
                                        <td><?php echo e($item->ukom->ukom_nama); ?></td>

                                        <td class="d-flex justify-content-center mx-auto">
                                            <div class="row btn-group">
                                                <div class="col-sm-12 col-md-12 col-lg-12 btn-group">
                                                    
                                                    <button type="button" class="btn btn-sm btn-danger" data-toggle="modal"
                                                        data-target="#modalhapus<?php echo e($item->id); ?>">
                                                        Hapus
                                                    </button>
                                                </div>
                                            </div>

                                            
                                            <div class="modal fade" id="modalhapus<?php echo e($item->id); ?>" tabindex="-1"
                                                role="dialog" aria-labelledby="exampleModalLabelLogout" aria-hidden="true">
                                                <div class="modal-dialog" role="document">
                                                    <div class="modal-content">
                                                        <div class="modal-header">
                                                            <h5 class="modal-title" id="exampleModalLabelLogout">Hapus data
                                                                Ujian
                                                            </h5>
                                                            <button type="button" class="close" data-dismiss="modal"
                                                                aria-label="Close">
                                                                <span aria-hidden="true">&times;</span>
                                                            </button>
                                                        </div>

                                                        <form action="<?php echo e(route('hapus-ujian', $item->id)); ?>"
                                                            method="POST">
                                                            <?php echo csrf_field(); ?>
                                                            <input type="hidden" name="id_ukom"
                                                                value="<?php echo e($item->id); ?>">
                                                            <div class="modal-body">
                                                                <div class="row">
                                                                    <div class="col-sm-12 col-md-12 col-lg-12">
                                                                        Apakah anda Yakin ingin menghapus data ini?
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="modal-footer">
                                                                <button type="button" class="btn btn-outline-primary"
                                                                    data-dismiss="modal">Batalkan</button>
                                                                <button type="submit"
                                                                    class="btn btn-primary">Simpan</button>
                                                            </div>
                                                        </form>

                                                    </div>
                                                </div>
                                            </div>

                                        </td>

                                        </td>

                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </tbody>

                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
    <script src="<?php echo e(asset('datatables')); ?>/datatables.min.js"></script>
    <script>
        $(document).ready(function() {
            $('#example').DataTable();
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.dashboard-layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\IT Ecoasphalt\Desktop\htdocs\ujikom\resources\views/ujian/jadwal-ujian.blade.php ENDPATH**/ ?>